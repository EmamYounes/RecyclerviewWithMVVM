package com.example.recyclerviewwithmvvm.model

class NicePlaces() {
    var title: String = ""
    var imageUrl: String = ""
}